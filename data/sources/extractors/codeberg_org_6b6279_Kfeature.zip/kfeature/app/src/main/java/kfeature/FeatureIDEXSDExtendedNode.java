package kfeature;

import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.FeatureMap;

import FeatureIDEXSD.Node;

// TODO Add description
public class FeatureIDEXSDExtendedNode {
    
    private final FeatureMap.Entry nodeMapping;
    private final Node parent;

    public FeatureIDEXSDExtendedNode(FeatureMap.Entry mapping, Node parent) {
        this.nodeMapping = mapping;
        this.parent = parent;
    }

    public FeatureMap.Entry getNodeMapping() {
        return nodeMapping;
    }

    public Node getSimpleNode() {
        return (Node) nodeMapping.getValue();
    }

    public EStructuralFeature getNodeType() {
        return nodeMapping.getEStructuralFeature();
    }

    public Node getParent() {
        return parent;
    }
    
}
