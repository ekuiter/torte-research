package kfeature.util;

import java.util.Collection;
import java.util.Iterator;

import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.FeatureMapUtil;

import FeatureIDEXSD.ConjType;
import FeatureIDEXSD.FeatureIDEXSDFactory;
import FeatureIDEXSD.ImpType;
import FeatureIDEXSD.VarType;

import FeatureIDEXSD.FeatureIDEXSDPackage.Literals;
import kfeature.KConfigNode;

public class FeatureIDEXSDExpressionUtil {

    static public FeatureMap.Entry buildVarType(KConfigNode node) {
        FeatureIDEXSDFactory factory = FeatureIDEXSDFactory.eINSTANCE;
        VarType nodeVar = factory.createVarType();
        FeatureMapUtil.addText(nodeVar.getMixed(), node.getName());
        return FeatureMapUtil.createEntry(Literals.DOCUMENT_ROOT__VAR, nodeVar);
    }

    static public FeatureMap.Entry buildConjType(Collection<FeatureMap.Entry> expressions) {
        FeatureIDEXSDFactory factory = FeatureIDEXSDFactory.eINSTANCE;
        if (expressions.isEmpty()) return null;
        ConjType rootConj = factory.createConjType();
        ConjType lastConj = rootConj;
        Iterator<FeatureMap.Entry> expressionsIterator = expressions.iterator();
        while (true) {
            lastConj.getExpressionListGroup().add(expressionsIterator.next());
            if (expressionsIterator.hasNext()) {
            ConjType newConj = factory.createConjType();
            lastConj.getExpressionListGroup().add(Literals.DOCUMENT_ROOT__CONJ, newConj);
            lastConj = newConj;
            continue;
            }
            break;
        }
        return FeatureMapUtil.createEntry(Literals.DOCUMENT_ROOT__CONJ, rootConj);
    }

    static public FeatureMap.Entry buildImpType(FeatureMap.Entry leftSide, FeatureMap.Entry rightSide) {
        FeatureIDEXSDFactory factory = FeatureIDEXSDFactory.eINSTANCE;
        ImpType implication = factory.createImpType();
        implication.getExpressionListGroup().add(leftSide);
        implication.getExpressionListGroup().add(rightSide);
        return FeatureMapUtil.createEntry(Literals.DOCUMENT_ROOT__IMP, implication);
    }
    
}
