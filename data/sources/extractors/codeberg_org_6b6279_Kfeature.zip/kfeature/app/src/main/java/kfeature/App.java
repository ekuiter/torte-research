package kfeature;

import java.io.File;
import java.io.IOException;

import org.antlr.runtime.tree.CommonTree;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.ParseException;

import FeatureIDEXSD.FeatureModelType;

import org.apache.commons.cli.Options;

public class App {

    private static String DEFAULT_OUTPUT_FILE_PREFIX = "_feature-model.xml";

    /**
     * This class provides the command-line interface of Kfeature. We use the Apache
     * Commons CLI library to handle command-line arguments/options.
     * 
     * Kfeature accepts following command-line options:
     * 
     * "-i" for the path of the input Kconfig file
     * 
     * "-o" for the path of the output FeatureIDE XML file (this is optional)
     * 
     * "-c" if the created feature model should be validated using kmax. This only
     * works for Kconfig files without tristate symbols.
     * 
     * "-v" should enable verbose mode, but this is not yet implemented.
     * 
     * This method then goes through the entire pipeline. See the inline comments for details.
     * 
     * @param args Command-line arguments with which Kfeature should be invoked
     */
    public static void main(String[] args) {
        Options options = new Options();
        options.addOption("i", true, "Path of the input file in Kconfig format");
        options.addOption("o", true, "Path of the output file");
        options.addOption("c", false, "Validate created feature model after transfoming");
        options.addOption("v", false, "Be more verbose");
        // TODO Implement logging facility for verbose output

        CommandLineParser parser = new DefaultParser();

        try {
            CommandLine cmd = parser.parse(options, args);
            if (cmd.hasOption("i")) {
                File inputFile = new File(cmd.getOptionValue("i"));
                assert inputFile.exists();
                KFeatureParserDispatcher dispatcher = new KFeatureParserDispatcher();
                // Step one: Parse Kconfig file with ANTLR3
                CommonTree ast = dispatcher.parse(inputFile);
                // Step two: Bring AST to intermediate graph form
                TreeProcessor tp = new TreeProcessor();
                tp.processAST(ast, null);
                KConfigGraph graph = tp.getGraph();
                // Step three: Apply model transformations
                FeatureModelType fm = FeatureIDEXSDGraphProcessor.processGraph(graph);
                Serializer<FeatureModelType> serializer = new FeatureIDEXSDSerializer();
                File outputFile;
                /*
                 * If no explicit output file path was given, use default prefix and save the
                 * feature model in the same directory as the input Kconfig file.
                 */
                if (cmd.hasOption("o")) {
                    outputFile = new File(cmd.getOptionValue("o"));
                } else {
                    outputFile = new File(inputFile.getAbsolutePath() + DEFAULT_OUTPUT_FILE_PREFIX);
                }
                // Step four: Serialize ECore feature model to create XML file for FeatureIDE
                serializer.serialize(fm, outputFile);
                // Additional step: Validate created feature model with kmax/klocalizer
                if (cmd.hasOption("c")) {
                    if (KFeatureValidator.validateTransformation(inputFile.toPath(), outputFile.toPath())) {
                        System.out.print("Created feature model validated: Total equivalency");
                    } else {
                        System.out.print("Created feature model validated: No total equivalency");
                    }
                }
            } else {
                System.err.print("No input file specified. Exiting.");
                System.exit(-1);
            }
        } catch (ParseException exp) {
            System.err.println("Cannot parse command-line arguments: " + exp.getMessage());
        } catch (IOException exp) {
            System.err.println(exp.getMessage());
        }
    }
}
