package kfeature;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import org.antlr.runtime.tree.CommonTree;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.collections4.multimap.ArrayListValuedHashMap;

public class TreeProcessor {

	private final KConfigGraph graph = new KConfigGraph(new HashMap<String, KConfigNode>(),
			new ArrayListValuedHashMap<KConfigNode, KConfigNode>());

	public KConfigGraph getGraph() {
		if (graph.nodes().values().stream().anyMatch(e -> e.getType() == KConfigNodeType.UNKNOWN)) {
			throw new IllegalStateException("Kconfig file incomplete: Undefined nodes appear in generated graph!");
		}
		return graph;
	}

	public void processAST(CommonTree ast, KConfigNode enclosingNode) {
		if (null == ast.getParent()) {
			// This is the root of our parse tree. Traverse through the children
			for (Object child : ast.getChildren()) {
				processAST((CommonTree) child, null);
			}
			// Close all nodes once we are done traversing
			graph.nodes().values().forEach((e) -> e.close());
			// Sort dependencies according to heuristic (see rule 1)
			sortDependencies();
			return;
		}
		switch (ast.getType()) {
			case LKCParser.CONFIG, LKCParser.MENUCONFIG:
				// "config" rule: Plain config symbol
				processConfigSymbol(ast, enclosingNode);
				break;
			case LKCParser.CHOICE:
				processChoice(ast, enclosingNode);
				break;
			case LKCParser.MENU:
				processMenu(ast, enclosingNode);
				break;
		}
	}

	private void sortDependencies() {
		for (KConfigNode currentNode : graph.nodes().values()) {
			graph.dependencies().get(currentNode).sort(Comparator.comparingInt(cs -> calculateNodeDepth(cs)));
		}
	}

	private int calculateNodeDepth(KConfigNode node) {
		return calculateNodeDepth(node, List.of());
	}

	private int calculateNodeDepth(KConfigNode node, List<KConfigNode> alreadyVisited) {
		int minimumParentDepth = 0;
		for (KConfigNode dependee : graph.dependencies().get(node)) {
			if (alreadyVisited.contains(dependee))
				throw new IllegalStateException("Graph contains cyclic dependencies! Transformation halted.");
			int parentDepth = calculateNodeDepth(dependee, ListUtils.union(alreadyVisited, List.of(node)));
			if (minimumParentDepth == 0 || parentDepth < minimumParentDepth)
				minimumParentDepth = parentDepth;
		}
		return node.getType().equals(KConfigNodeType.MENUCONFIG) ? -100 + minimumParentDepth : 1 + minimumParentDepth;
		// Manipulate depth value to favour dependency paths with menuconfig symbols
	}

	private void processMenu(CommonTree ast, KConfigNode enclosingNode) {
		String nodeName = ast.getChild(0).getText();
		KConfigNode cs;
		cs = new KConfigNode();
		cs.setName(nodeName);
		cs.setType(KConfigNodeType.MENU);
		cs.setEnclosingNode(enclosingNode);
		for (Object child : ast.getChildren()) { // We have to iterate over Objects because the CommonTree class does
													// not have a method that returns a list of its children as
													// CommonTree instances.
			CommonTree option = (CommonTree) child;
			/*
			 * Instead of using magic strings, we retrieve token values off the static
			 * fields of the generated Parser class.
			 */
			switch (option.getType()) {
				case LKCParser.DEPENDS:
					processDependency(cs, option, false);
					break;
				case LKCParser.BLOCK:
					for (Object subtrees : option.getChildren()) {
						processAST((CommonTree) subtrees, cs);
					}
					break;
			}
		}
		graph.nodes().put(nodeName, cs);
	}

	private void processChoice(CommonTree ast, KConfigNode enclosingNode) {
		String nodeName = ast.getChild(0).getText();
		KConfigNode cs;
		cs = graph.nodes().get(nodeName);
		if (null == cs) { // If this config symbol wasn't mentioned until now
			cs = new KConfigNode();
			cs.setName(nodeName);
		}
		cs.setEnclosingNode(enclosingNode);
		cs.toggleOptional();
		for (Object child : ast.getChildren()) { // We have to iterate over Objects because the CommonTree class does
													// not have a method that returns a list of its children as
													// CommonTree instances.
			CommonTree option = (CommonTree) child;
			/*
			 * Instead of using magic strings, we retrieve token values off the static
			 * fields of the generated Parser class.
			 */
			switch (option.getType()) {
				case LKCParser.DEPENDS:
					processDependency(cs, option, false);
					break;
				case LKCParser.SELECT:
					processDependency(cs, option, true);
					break;
				case LKCParser.T__49:
				case LKCParser.T__50:
					// "bool" is an alias for "boolean" (nevertheless valid syntax)
					cs.setType(KConfigNodeType.CHOICE_BOOLEAN);
					break;
				case LKCParser.T__53:
					cs.setType(KConfigNodeType.CHOICE_TRISTATE);
					break;
				case LKCParser.CONFIG:
					processConfigSymbol(option, cs);
					break;
				case LKCParser.OPTIONAL:
					if (!cs.isOptional())
						cs.toggleOptional();
			}
		}
		graph.nodes().put(nodeName, cs);
	}

	private void processConfigSymbol(CommonTree ast, KConfigNode enclosingNode) {
		/*
		 * We build the config symbol "on-line": The initial stub is created upon
		 * calling this method, the node type and the concrete name of the node is
		 * initialized once the respective options are processed in the following `for`
		 * loop.
		 */
		String nodeName = ast.getChild(0).getText();
		KConfigNode cs;
		cs = graph.nodes().get(nodeName);
		if (null == cs) { // If this config symbol wasn't mentioned until now
			cs = new KConfigNode();
			cs.setName(nodeName);
		}
		cs.setEnclosingNode(enclosingNode);
		for (Object child : ast.getChildren()) { // We have to iterate over Objects because the CommonTree class does
													// not have a method that returns a list of its children as
													// CommonTree instances.
			CommonTree option = (CommonTree) child;
			/*
			 * Instead of using magic strings, we retrieve token values off the static
			 * fields of the generated Parser class.
			 */
			switch (option.getType()) {
				case LKCParser.DEPENDS:
					processDependency(cs, option, false);
					break;
				case LKCParser.SELECT:
					processDependency(cs, option, false);
					break;
				case LKCParser.T__49:
				case LKCParser.T__50:
					// "bool" is an alias for "boolean" (nevertheless valid syntax)
					if (ast.getType() == LKCLexer.MENUCONFIG) {
						cs.setType(KConfigNodeType.MENUCONFIG);
					} else {
						cs.setType(KConfigNodeType.BOOLEAN);
					}
					break;
				case LKCParser.T__53:
					cs.setType(KConfigNodeType.TRISTATE);
					break;
			}
		}
		graph.nodes().put(nodeName, cs);
	}

	/***
	 * Process the given dependency option within a config symbol definition.
	 * 
	 * @param cs                The source node of the dependency, i.e. the
	 *                          depender.
	 * @param option            The subtree containing the dependency option to be
	 *                          processed. This should correspond to the name of the
	 *                          target node of the dependency, i.e. the dependee.
	 * @param reverseDependency If set to true, the dependency is reversed; use this
	 *                          to process the `select` option in configuration
	 *                          symbols.
	 */
	private void processDependency(KConfigNode cs, CommonTree option, boolean reverseDependency) {
		var targetName = option.getChild(0).getText();
		// Check if the target node is already present
		var targetNode = graph.nodes().get(targetName);
		if (null == targetNode) {
			// Target node was not processed yet, create placeholder node with unknown type
			targetNode = new KConfigNode(targetName, KConfigNodeType.UNKNOWN, null);
			graph.nodes().put(targetName, targetNode);
		}
		if (reverseDependency) {
			graph.dependencies().put(targetNode, cs);
		} else {
			graph.dependencies().put(cs, targetNode);
		}
	}
}
