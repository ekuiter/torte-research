package kfeature;

import java.io.File;

import org.eclipse.emf.ecore.EObject;

public interface Serializer<T extends EObject> {

    /**
     * TODO
     * @param emfStruct
     * @param target
     */
    void serialize(T emfStruct, File target);

}
