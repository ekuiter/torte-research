package kfeature;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

import FeatureIDEXSD.DocumentRoot;
import FeatureIDEXSD.FeatureIDEXSDFactory;
import FeatureIDEXSD.FeatureModelType;
import FeatureIDEXSD.util.FeatureIDEXSDResourceFactoryImpl;

public class FeatureIDEXSDSerializer implements Serializer<FeatureModelType> {

    @Override
    public void serialize(FeatureModelType emfStruct, File target) {
        FeatureIDEXSDFactory factory = FeatureIDEXSDFactory.eINSTANCE;
        Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
        Map<String, Object> mapping = reg.getExtensionToFactoryMap();
        mapping.put(FilenameUtils.getExtension(target.getAbsolutePath()), new FeatureIDEXSDResourceFactoryImpl());

        // We need a resource set to contain our resource
        ResourceSet rs = new ResourceSetImpl();
        Resource fmResource = rs.createResource(URI.createURI(target.getAbsolutePath()));

        // Add the given feature model to the resource
        DocumentRoot wrapper = factory.createDocumentRoot();
        wrapper.setFeatureModel(emfStruct);
        fmResource.getContents().add(wrapper);

        // Now save the resource
        try {
            fmResource.save(Collections.EMPTY_MAP);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Serialisation complete! Check if the file was saved correctly
        
    }
    
}
