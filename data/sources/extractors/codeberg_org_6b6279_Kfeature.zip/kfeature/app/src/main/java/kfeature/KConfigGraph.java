package kfeature;

import java.util.Map;

import org.apache.commons.collections4.ListValuedMap;

record KConfigGraph(Map<String, KConfigNode> nodes, ListValuedMap<KConfigNode, KConfigNode> dependencies) {}
