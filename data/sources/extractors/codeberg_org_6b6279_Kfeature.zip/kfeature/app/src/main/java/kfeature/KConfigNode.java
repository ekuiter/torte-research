package kfeature;

public class KConfigNode {

	private boolean immutable = false;
	private boolean optional = true;
	private String name;
	private KConfigNodeType type;
	private KConfigNode enclosingNode;

	public KConfigNode() {
		this.enclosingNode = null;
	}

	public KConfigNode(String name, KConfigNodeType type, KConfigNode enclosing) {
		this.name = name;
		this.type = type;
		this.enclosingNode = enclosing;
	}

	public void setEnclosingNode(KConfigNode enclosingNode) {
		this.enclosingNode = enclosingNode;
	}

	public KConfigNode getEnclosingNode() {
		return enclosingNode;
	}

	public boolean isOptional() {
		return optional;
	}

	public void toggleOptional() {
		this.optional = !this.optional;
	}

	// TODO Move this method to an interface "Closable"
	public void close() {
		if (immutable)
			throw new UnsupportedOperationException("This instance has already been consummated!");
		this.immutable = true;
	}

	public String getName() {
		return name;
	}

	public KConfigNodeType getType() {
		return type;
	}

	public void setName(String name) {
		if (immutable)
			throw new UnsupportedOperationException("This instance has already been consummated!");
		this.name = name;
	};

	public void setType(KConfigNodeType type) {
		if (immutable)
			throw new UnsupportedOperationException("This instance has already been consummated!");
		this.type = type;
	}

	@Override
	public boolean equals(Object o) {
		// Two config symbols cannot have the same name
		// This should cause a mismatch regardless of the symbol type
		if (o instanceof KConfigNode) {
			if (this.name.equals(((KConfigNode) o).getName()))
				return true;
		}
		return false;
	}

}
