package kfeature;

import java.util.Collection;
import java.util.List;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.FeatureMapUtil;

import FeatureIDEXSD.AltType;
import FeatureIDEXSD.AndType;
import FeatureIDEXSD.ConstraintsType;
import FeatureIDEXSD.DisjType;
import FeatureIDEXSD.FeatureIDEXSDFactory;
import FeatureIDEXSD.FeatureIDEXSDPackage;
import FeatureIDEXSD.FeatureIDEXSDPackage.Literals;
import FeatureIDEXSD.FeatureModelType;
import FeatureIDEXSD.ImpType;
import FeatureIDEXSD.Node;
import FeatureIDEXSD.OrType;
import FeatureIDEXSD.RuleType;
import FeatureIDEXSD.StructType;
import FeatureIDEXSD.VarType;
import FeatureIDEXSD.impl.FeatureIDEXSDPackageImpl;
import kfeature.util.FeatureIDEXSDExpressionUtil;
import kfeature.util.NodeUtil;

public class FeatureIDEXSDGraphProcessor {

        static final private String TRISTATE_TRUE_SUBFEATURE_SUFFIX = "_T";
        static final private String TRISTATE_MODULE_SUBFEATURE_SUFFIX = "_M";
        // static final private String EXTERNAL_ROOT_NODE_NAME = "EXTERNAL";
        static final private String ROOT_NODE_NAME = "Kconfig";

        /***
         * Creates a feature model using the data found within the given TreeProcessor
         * instance.
         * 
         * The created feature model is outputed immediately as an XML file using the
         * serialize method. This XML file can be viewed using FeatureIDE.
         * 
         * TODO Add detailed description of what this method does
         * 
         * @param tp An already used TreeProcessor instance containing the Kconfig file
         *           in graph form
         */
        // Build a feature model using the data contained in a finalised TreeProcessor
        static public FeatureModelType processGraph(KConfigGraph graph) {
                // Initialize model package and factory
                FeatureIDEXSDPackageImpl.init();
                FeatureIDEXSDFactory factory = FeatureIDEXSDFactory.eINSTANCE;
                // First step: Initialize new feature model and convert nodes to features
                FeatureModelType fm = factory.createFeatureModelType();
                StructType struct = factory.createStructType();
                // Create the root node
                AndType root = factory.createAndType();
                root.setName(ROOT_NODE_NAME);
                root.setMandatory(true);
                root.setAbstract(true);
                // Process the internal nodes
                // Add them directly to the root of the feature model
                for (KConfigNode node : graph.nodes().values()) {
                        processNode(node, root);
                }
                // Second step: Convert dependencies into constraints
                ConstraintsType constraints = factory.createConstraintsType();

                for (Entry<KConfigNode, Collection<KConfigNode>> dependency : graph.dependencies().asMap().entrySet()) {
                        KConfigNode sourceNode = dependency.getKey();
                        for (KConfigNode targetNode : dependency.getValue()) {
                                constraints.getRule().addAll(processRule(sourceNode, targetNode, root));
                        }
                        if (sourceNode.getType() == KConfigNodeType.CHOICE_BOOLEAN && !sourceNode.isOptional()) {
                                constraints.getRule()
                                                .addAll(processMandatoryChoiceBlock(sourceNode, dependency.getValue(), root));
                        }
                }

                // Third step: Combine all components to create a feature model
                struct.getNodeListGroup()
                                .add(FeatureMapUtil.createEntry(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__AND,
                                                root));
                fm.setStruct(struct);
                fm.setConstraints(constraints);
                return fm;
        }

        private static Collection<? extends RuleType> processMandatoryChoiceBlock(KConfigNode sourceNode, Collection<KConfigNode> dependees, AndType root) {

                // Because the choice block has dependencies, it is no longer necessary to set the feature corresponding to the choice header mandatory.
                findFeature(sourceNode.getName(), root).getSimpleNode().setMandatory(false);

                FeatureIDEXSDFactory factory = FeatureIDEXSDFactory.eINSTANCE;
                List<FeatureMap.Entry> listOfVariables = dependees.stream()
                                .map(e -> FeatureIDEXSDExpressionUtil.buildVarType(e)).collect(Collectors.toList());
                FeatureMap.Entry conjugationOfDependencies = FeatureIDEXSDExpressionUtil.buildConjType(listOfVariables);
                FeatureMap.Entry sourceNodeVariable = FeatureIDEXSDExpressionUtil.buildVarType(sourceNode);
                FeatureMap.Entry implication = FeatureIDEXSDExpressionUtil.buildImpType(conjugationOfDependencies,
                                sourceNodeVariable);
                RuleType mandatoryChoiceBlockRule = factory.createRuleType();
                mandatoryChoiceBlockRule.getExpressionListGroup().add(implication);
                return List.of(mandatoryChoiceBlockRule);
        }

        /**
         * Convert given config symbol (represented by a KConfigNode object) to a
         * feature (or multiple features). The transformation is applied based on the
         * type of the config symbol.
         * 
         * @param node    the KConfigNode instance to process, represents a config
         *                symbol
         * @param factory factory instance to use during the transformation
         * @return
         */
        static private void processNode(KConfigNode node, Node root) {
                FeatureIDEXSDFactory factory = FeatureIDEXSDFactory.eINSTANCE;
                if (findFeature(node.getName(), root) != null)
                        return;
                switch (node.getType()) {
                        case BOOLEAN, MENU, MENUCONFIG:
                                // Rule 1: A boolean config symbol corresponds to a feature (A eqv. A)
                                AndType feature = factory.createAndType();
                                if (node.getType() == KConfigNodeType.MENU) {
                                        feature.setMandatory(true);
                                        feature.setAbstract(true);
                                }
                                feature.setName(node.getName());
                                if (node.getEnclosingNode() == null) {
                                        NodeUtil.getChildNodes(root)
                                                        .add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__AND, feature);
                                } else {
                                        FeatureIDEXSDExtendedNode immediateParent = findFeature(
                                                        node.getEnclosingNode().getName(), root);
                                        if (immediateParent == null) {
                                                processNode(node.getEnclosingNode(), root);
                                                immediateParent = findFeature(node.getEnclosingNode().getName(), root);
                                        }
                                        NodeUtil.getChildNodes(immediateParent.getSimpleNode())
                                                        .add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__AND, feature);
                                }
                                return;
                        case TRISTATE:
                                /*
                                 * Rule 2: A tristate config symbol corresponds to three features:
                                 * The features A_T and A_M correspond to the states "true" and "module",
                                 * respectively. These child features depend on A. Hence selecting feature A
                                 * implies that the config symbol A is at least set to "module". The config
                                 * symbol A is set to false when the feature A is not selected.
                                 * (A eqv. A -> A_T OR A_M)
                                 */
                                AndType nodeModuleState = factory.createAndType();
                                AndType nodeTrueState = factory.createAndType();
                                nodeModuleState.setName(node.getName() + TRISTATE_MODULE_SUBFEATURE_SUFFIX);
                                nodeTrueState.setName(node.getName() + TRISTATE_TRUE_SUBFEATURE_SUFFIX);
                                AltType nodeNullState = factory.createAltType();
                                nodeNullState.setName(node.getName());
                                nodeNullState.setAbstract(true);
                                NodeUtil.getChildNodes(nodeNullState).add(
                                                FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__AND,
                                                nodeModuleState);
                                NodeUtil.getChildNodes(nodeNullState).add(
                                                FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__AND,
                                                nodeTrueState);
                                if (node.getEnclosingNode() != null) {
                                        if (node.getEnclosingNode().getType() == KConfigNodeType.CHOICE_TRISTATE) {
                                                FeatureIDEXSDExtendedNode immediateModuleParent = findFeature(
                                                                node.getEnclosingNode().getName()
                                                                                + TRISTATE_MODULE_SUBFEATURE_SUFFIX,
                                                                root);
                                                if (immediateModuleParent == null) {
                                                        processNode(node.getEnclosingNode(), root);
                                                        immediateModuleParent = findFeature(
                                                                        node.getEnclosingNode().getName()
                                                                                        + TRISTATE_MODULE_SUBFEATURE_SUFFIX,
                                                                        root);
                                                }
                                                FeatureIDEXSDExtendedNode immediateTrueParent = findFeature(
                                                                node.getEnclosingNode().getName()
                                                                                + TRISTATE_TRUE_SUBFEATURE_SUFFIX,
                                                                root);
                                                NodeUtil.getChildNodes(immediateModuleParent.getSimpleNode())
                                                                .add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__AND,
                                                                                nodeModuleState);
                                                NodeUtil.getChildNodes(immediateTrueParent.getSimpleNode())
                                                                .add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__AND,
                                                                                nodeTrueState);
                                        } else { // Enclosing node is a menu
                                                FeatureIDEXSDExtendedNode enclosingMenu = findFeature(
                                                                node.getEnclosingNode().getName(), root);
                                                if (enclosingMenu == null) {
                                                        processNode(node.getEnclosingNode(), root);
                                                        enclosingMenu = findFeature(
                                                                        node.getEnclosingNode().getName(), root);
                                                }
                                                NodeUtil.getChildNodes(enclosingMenu.getSimpleNode())
                                                                .add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__ALT,
                                                                                nodeNullState);
                                        } // There are only two cases that might occur in a valid Kconfig file
                                } else {
                                        NodeUtil.getChildNodes(root).add(
                                                        FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__ALT,
                                                        nodeNullState);
                                }
                                return;
                        case CHOICE_BOOLEAN:
                                AltType choice = factory.createAltType();
                                choice.setName(node.getName());
                                choice.setMandatory(!node.isOptional());
                                choice.setAbstract(true);
                                if (node.getEnclosingNode() != null) {
                                        FeatureIDEXSDExtendedNode enclosingMenu = findFeature(
                                                        node.getEnclosingNode().getName(), root);
                                        if (enclosingMenu == null) {
                                                processNode(node.getEnclosingNode(), root);
                                                enclosingMenu = findFeature(
                                                                node.getEnclosingNode().getName(), root);
                                        }
                                        NodeUtil.getChildNodes(enclosingMenu.getSimpleNode())
                                                        .add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__ALT, choice);
                                } else {
                                        NodeUtil.getChildNodes(root)
                                                        .add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__ALT, choice);
                                }
                                return;
                        case CHOICE_TRISTATE:
                                AltType choiceNullState = factory.createAltType();
                                choiceNullState.setName(node.getName());
                                //choiceNullState.setMandatory(!node.isOptional());
                                // Tristate choice blocks cannot be set to mandatory due to an Kconfig implementation bug
                                choiceNullState.setAbstract(true);
                                OrType choiceModuleState = factory.createOrType();
                                choiceModuleState.setAbstract(true);
                                choiceModuleState.setName(node.getName() + TRISTATE_MODULE_SUBFEATURE_SUFFIX);
                                AltType choiceTrueState = factory.createAltType();
                                choiceTrueState.setAbstract(true);
                                choiceTrueState.setName(node.getName() + TRISTATE_TRUE_SUBFEATURE_SUFFIX);
                                NodeUtil.getChildNodes(choiceNullState).add(
                                                FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__OR,
                                                choiceModuleState);
                                NodeUtil.getChildNodes(choiceNullState).add(
                                                FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__ALT,
                                                choiceTrueState);
                                NodeUtil.getChildNodes(root).add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__ALT,
                                                choiceNullState);
                                return;
                        default:
                                throw new UnsupportedOperationException("Cannot process node: Unknown node type.");
                }
        }

        /**
         * Process a dependency between the config symbols `source` and `target`.
         * 
         * This method manipulates the structure of the feature model over the given
         * `root` feature. Some dependencies cannot be transformed merely through
         * structural changes. If cross-tree constraints are required to transform a
         * dependency, this method will output cross-tree constraints (possibly multiple
         * of them, hence the List output). These RuleType instances should be added to
         * the respective ConstraintsType instance by the caller.
         * 
         * @param source  The left-hand side of the dependency (depender)
         * @param target  The right-hand side of the dependency (dependee)
         * @param root    Root of the feature model (AndType by default, see
         *                processGraph)
         * @param factory Factory instance to be used to initialize new
         *                Nodes/Expressions
         * @return List containing RuleType instances representing cross-tree
         *         constraints to be added to the respective feature model
         */
        static private List<RuleType> processRule(KConfigNode source, KConfigNode target, AndType root) {
                FeatureIDEXSDFactory factory = FeatureIDEXSDFactory.eINSTANCE;
                FeatureIDEXSDExtendedNode sourceFeatureIDENode = findFeature(source.getName(), root);
                FeatureIDEXSDExtendedNode targetFeatureIDENode = findFeature(target.getName(), root);
                switch (source.getType()) {
                        case BOOLEAN, CHOICE_BOOLEAN, MENU, MENUCONFIG:
                                switch (target.getType()) {
                                        case BOOLEAN, MENUCONFIG:
                                                /*
                                                 * Rule 3: Boolean config symbol depends on another boolean config
                                                 * symbol
                                                 * -> Make source node child of target node
                                                 */
                                                if (source.getEnclosingNode() != null
                                                                || !sourceFeatureIDENode.getParent().equals(root)) {
                                                        /*
                                                         * There is an enclosing node, do not represent other
                                                         * dependencies structurally.
                                                         */
                                                        RuleType dependencyRule = factory.createRuleType();
                                                        ImpType dependencyRuleExpression = buildSimpleImplication(
                                                                        sourceFeatureIDENode.getSimpleNode(),
                                                                        targetFeatureIDENode.getSimpleNode());
                                                        dependencyRule.getExpressionListGroup().add(
                                                                        Literals.DOCUMENT_ROOT__IMP,
                                                                        dependencyRuleExpression);
                                                        return List.of(dependencyRule);
                                                }
                                                moveNode(sourceFeatureIDENode.getNodeMapping(),
                                                                sourceFeatureIDENode.getParent(),
                                                                targetFeatureIDENode.getSimpleNode());
                                                // Emit no cross-tree constraints
                                                return List.of();
                                        case TRISTATE, CHOICE_TRISTATE:
                                                /**
                                                 * Rule 4: Boolean config symbol depends on a tristate config symbol
                                                 * -> Add rule: <source> implies <target>
                                                 * (Structural depiction of this dependency is not possible as ALT/OR
                                                 * groups cannot be limited to certain children)
                                                 */
                                                RuleType dependencyRule = factory.createRuleType();
                                                ImpType dependencyRuleExpression = factory.createImpType();
                                                if (target.getEnclosingNode() != null
                                                                && target.getEnclosingNode()
                                                                                .getType() == KConfigNodeType.CHOICE_TRISTATE) {
                                                        /*
                                                         * Rule 6: If a boolean symbol depends on another tristate
                                                         * symbol that is enclosed in a choice block, replace
                                                         * implication target with OR expression
                                                         */
                                                        FeatureIDEXSDExtendedNode targetModuleState = findFeature(
                                                                        target.getName() + TRISTATE_MODULE_SUBFEATURE_SUFFIX,
                                                                        root);
                                                        FeatureIDEXSDExtendedNode targetTrueState = findFeature(
                                                                        target.getName() + TRISTATE_TRUE_SUBFEATURE_SUFFIX,
                                                                        root);

                                                        VarType sourceNodeVar = factory.createVarType();
                                                        VarType targetTrueStateVar = factory.createVarType();
                                                        VarType targetModuleStateVar = factory.createVarType();
                                                        DisjType targetExpression = factory.createDisjType();

                                                        FeatureMapUtil.addText(sourceNodeVar.getMixed(),
                                                                        sourceFeatureIDENode.getSimpleNode().getName());
                                                        FeatureMapUtil.addText(targetModuleStateVar.getMixed(),
                                                                        targetModuleState.getSimpleNode().getName());
                                                        FeatureMapUtil.addText(targetTrueStateVar.getMixed(),
                                                                        targetTrueState.getSimpleNode().getName());
                                                        targetExpression.getExpressionListGroup().add(
                                                                        Literals.DOCUMENT_ROOT__VAR,
                                                                        targetModuleStateVar);
                                                        targetExpression.getExpressionListGroup().add(
                                                                        Literals.DOCUMENT_ROOT__VAR,
                                                                        targetTrueStateVar);

                                                        dependencyRuleExpression.getExpressionListGroup().add(
                                                                        Literals.DOCUMENT_ROOT__VAR,
                                                                        sourceNodeVar);
                                                        dependencyRuleExpression.getExpressionListGroup().add(
                                                                        Literals.DOCUMENT_ROOT__DISJ,
                                                                        targetExpression);
                                                } else {
                                                        dependencyRuleExpression = buildSimpleImplication(
                                                                        sourceFeatureIDENode.getSimpleNode(),
                                                                        targetFeatureIDENode.getSimpleNode());
                                                }
                                                dependencyRule.getExpressionListGroup().add(Literals.DOCUMENT_ROOT__IMP,
                                                                dependencyRuleExpression);
                                                return List.of(dependencyRule);
                                        case CHOICE_BOOLEAN:
                                                // Rule 5: Never process dependencies to choice blocks structurally
                                                RuleType booleanChoiceDependencyRule = factory.createRuleType();
                                                ImpType booleanChoiceDependencyRuleExpression = buildSimpleImplication(
                                                                sourceFeatureIDENode.getSimpleNode(),
                                                                targetFeatureIDENode.getSimpleNode());
                                                booleanChoiceDependencyRule.getExpressionListGroup().add(
                                                                Literals.DOCUMENT_ROOT__IMP,
                                                                booleanChoiceDependencyRuleExpression);
                                                return List.of(booleanChoiceDependencyRule);
                                        case MENU:
                                                // Menus cannot occur as dependees
                                                throw new UnsupportedOperationException(
                                                                "Cannot process constaint: Constaint has menu node on right-hand side");
                                        default:
                                                throw new UnsupportedOperationException(
                                                                "Cannot process constraint: Unknown node type (right-hand side).");
                                }
                        case TRISTATE, CHOICE_TRISTATE:
                                switch (target.getType()) {
                                        case BOOLEAN, MENUCONFIG:
                                                // Rule 5: Tristate config symbol depends on a boolean config symbol
                                                // -> Make main tristate node (parent of *{_T, _M}) child of the target
                                                // node
                                                if (source.getEnclosingNode() != null
                                                                || !sourceFeatureIDENode.getParent().equals(root)) {
                                                        /*
                                                         * There is an enclosing node, do not represent other
                                                         * dependencies structurally.
                                                         * OR
                                                         * We have already processed a dependency involving this node.
                                                         * Represent only the first dependency structurally.
                                                         */
                                                        RuleType dependencyRule = factory.createRuleType();
                                                        ImpType dependencyRuleExpression;
                                                        if (source.getEnclosingNode() != null && source.getEnclosingNode().getType() == KConfigNodeType.CHOICE_TRISTATE) {
                                                                FeatureIDEXSDExtendedNode sourceModuleState = findFeature(
                                                                        source.getName() + TRISTATE_MODULE_SUBFEATURE_SUFFIX,
                                                                        root);
                                                                FeatureIDEXSDExtendedNode sourceTrueState = findFeature(
                                                                        source.getName() + TRISTATE_TRUE_SUBFEATURE_SUFFIX,
                                                                        root);

                                                                dependencyRuleExpression = factory.createImpType();
                                                                VarType sourceModuleStateVar = factory.createVarType();
                                                                VarType sourceTrueStateVar = factory.createVarType();
                                                                VarType targetFeatureVar = factory.createVarType();
                                                                DisjType sourceExpression = factory.createDisjType();

                                                                FeatureMapUtil.addText(sourceModuleStateVar.getMixed(), sourceModuleState.getSimpleNode().getName());
                                                                FeatureMapUtil.addText(sourceTrueStateVar.getMixed(), sourceTrueState.getSimpleNode().getName());
                                                                FeatureMapUtil.addText(targetFeatureVar.getMixed(), targetFeatureIDENode.getSimpleNode().getName());
                                               
                                                                sourceExpression.getExpressionListGroup().add(Literals.DOCUMENT_ROOT__VAR, sourceModuleStateVar);
                                                                sourceExpression.getExpressionListGroup().add(Literals.DOCUMENT_ROOT__VAR, sourceTrueStateVar);
                                                                
                                                                dependencyRuleExpression.getExpressionListGroup().add(Literals.DOCUMENT_ROOT__DISJ, sourceExpression);
                                                                dependencyRuleExpression.getExpressionListGroup().add(Literals.DOCUMENT_ROOT__VAR, targetFeatureVar);
                                                        } else {
                                                                dependencyRuleExpression = buildSimpleImplication(sourceFeatureIDENode.getSimpleNode(), targetFeatureIDENode.getSimpleNode());
                                                        }
                                                        dependencyRule.getExpressionListGroup().add(Literals.DOCUMENT_ROOT__IMP, dependencyRuleExpression);
                                                        return List.of(dependencyRule);
                                                }
                                                moveNode(sourceFeatureIDENode.getNodeMapping(),
                                                                sourceFeatureIDENode.getParent(),
                                                                targetFeatureIDENode.getSimpleNode());
                                                // Emit no cross-tree constraints
                                                return List.of();
                                        case TRISTATE, CHOICE_TRISTATE:
                                                // Rule 6: Tristate config symbol depends on another tristate config
                                                // symbol
                                                // -> Add rules: <source>_M implies <target> and <source>_T implies
                                                // <target>_T
                                                FeatureIDEXSDExtendedNode sourceModuleState = findFeature(
                                                                source.getName() + TRISTATE_MODULE_SUBFEATURE_SUFFIX,
                                                                root);
                                                FeatureIDEXSDExtendedNode targetTrueState = findFeature(
                                                                target.getName() + TRISTATE_TRUE_SUBFEATURE_SUFFIX,
                                                                root);
                                                RuleType moduleRule = factory.createRuleType();
                                                ImpType moduleRuleExpression = factory.createImpType();
                                                if (target.getEnclosingNode() != null && target.getEnclosingNode()
                                                .getType() == KConfigNodeType.CHOICE_TRISTATE) {
                                                        /*
                                                         * Rule 6: If a tristate symbol depends on another tristate
                                                         * symbol that is
                                                         * enclosed in a choice block, replace implication target with
                                                         * OR expression
                                                         */
                                                                FeatureIDEXSDExtendedNode targetModuleState = findFeature(
                                                                                target.getName() + TRISTATE_MODULE_SUBFEATURE_SUFFIX,
                                                                                root);

                                                                VarType sourceModuleStateVar = factory.createVarType();
                                                                VarType targetTrueStateVar = factory.createVarType();
                                                                VarType targetModuleStateVar = factory.createVarType();
                                                                DisjType targetExpression = factory.createDisjType();

                                                                FeatureMapUtil.addText(sourceModuleStateVar.getMixed(),
                                                                                sourceModuleState.getSimpleNode()
                                                                                                .getName());
                                                                FeatureMapUtil.addText(targetModuleStateVar.getMixed(),
                                                                                targetModuleState.getSimpleNode()
                                                                                                .getName());
                                                                FeatureMapUtil.addText(targetTrueStateVar.getMixed(),
                                                                                targetTrueState.getSimpleNode()
                                                                                                .getName());
                                                                targetExpression.getExpressionListGroup().add(
                                                                                Literals.DOCUMENT_ROOT__VAR,
                                                                                targetModuleStateVar);
                                                                targetExpression.getExpressionListGroup().add(
                                                                                Literals.DOCUMENT_ROOT__VAR,
                                                                                targetTrueStateVar);

                                                                moduleRuleExpression.getExpressionListGroup().add(
                                                                                Literals.DOCUMENT_ROOT__VAR,
                                                                                sourceModuleStateVar);
                                                                moduleRuleExpression.getExpressionListGroup().add(
                                                                                Literals.DOCUMENT_ROOT__DISJ,
                                                                                targetExpression);
                                                } else {
                                                        FeatureIDEXSDExtendedNode targetNullState = findFeature(
                                                                        target.getName(), root);
                                                        moduleRuleExpression = buildSimpleImplication(
                                                                        sourceModuleState.getSimpleNode(),
                                                                        targetNullState.getSimpleNode());
                                                }
                                                moduleRule.getExpressionListGroup()
                                                                .add(Literals.DOCUMENT_ROOT__IMP, moduleRuleExpression);
                                                /*
                                                 * First rule generated. Now process second rule; no consideration of
                                                 * enclosing
                                                 * nodes required.
                                                 */
                                                FeatureIDEXSDExtendedNode sourceTrueState = findFeature(
                                                                source.getName() + TRISTATE_TRUE_SUBFEATURE_SUFFIX,
                                                                root);
                                                RuleType trueRule = factory.createRuleType();
                                                ImpType trueRuleExpression = buildSimpleImplication(
                                                                sourceTrueState.getSimpleNode(),
                                                                targetTrueState.getSimpleNode());
                                                trueRule.getExpressionListGroup().add(Literals.DOCUMENT_ROOT__IMP,
                                                                trueRuleExpression);
                                                return List.of(moduleRule, trueRule);
                                        case CHOICE_BOOLEAN:
                                                // Rule 5: Never process dependencies to choice blocks structurally
                                                RuleType dependencyRule = factory.createRuleType();
                                                ImpType dependencyRuleExpression = buildSimpleImplication(
                                                                sourceFeatureIDENode.getSimpleNode(),
                                                                targetFeatureIDENode.getSimpleNode());
                                                dependencyRule.getExpressionListGroup().add(Literals.DOCUMENT_ROOT__IMP,
                                                                dependencyRuleExpression);
                                                return List.of(dependencyRule);
                                        case MENU:
                                                // Menus cannot occur as dependees
                                                throw new UnsupportedOperationException(
                                                                "Cannot process constaint: Constaint has menu node on right-hand side");
                                        default:
                                                throw new UnsupportedOperationException(
                                                                "Cannot process constraint: Unknown node type (right-hand side).");
                                }
                        default:
                                throw new UnsupportedOperationException(
                                                "Cannot process constraint: Unknown node type (left-hand side).");

                }
        }

        static private FeatureIDEXSDExtendedNode findFeature(String featureName, Node root) {
                FeatureMap children = NodeUtil.getChildNodes(root);
                if (null != children) {
                        for (FeatureMap.Entry child : children) {
                                if (((Node) child.getValue()).getName().equals(featureName)) {
                                        return new FeatureIDEXSDExtendedNode(child, root);
                                } else {
                                        // Traverse deeper
                                        var subresult = findFeature(featureName, (Node) child.getValue());
                                        if (null != subresult)
                                                return subresult;
                                }
                        }
                }
                return null;
        }

        static private ImpType buildSimpleImplication(Node leftside, Node rightside) {
                FeatureIDEXSDFactory factory = FeatureIDEXSDFactory.eINSTANCE;

                ImpType implication = factory.createImpType();
                VarType sourceVar = factory.createVarType();
                VarType targetVar = factory.createVarType();

                // See https://www.theserverside.com/news/1364302/Binding-XML-to-Java
                // The "Mixed" field is used to put arbitrary text between XML tags
                FeatureMapUtil.addText(sourceVar.getMixed(), leftside.getName());
                FeatureMapUtil.addText(targetVar.getMixed(), rightside.getName());

                implication.getExpressionListGroup().add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__VAR,
                                sourceVar);
                implication.getExpressionListGroup().add(FeatureIDEXSDPackage.Literals.DOCUMENT_ROOT__VAR,
                                targetVar);

                return implication;
        }

        static private void moveNode(FeatureMap.Entry toMove, Node currentParent, Node newParent) {
                NodeUtil.getChildNodes(currentParent).remove(toMove);
                NodeUtil.getChildNodes(newParent).add(toMove);
        }
}
