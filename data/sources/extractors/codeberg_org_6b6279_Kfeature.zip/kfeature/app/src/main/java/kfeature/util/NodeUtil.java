package kfeature.util;

import org.eclipse.emf.ecore.util.FeatureMap;

import FeatureIDEXSD.*;

public class NodeUtil {

    private NodeUtil() {
        throw new UnsupportedOperationException("Utility classes may not be instantiated.");
    }

    static public FeatureMap getChildNodes(Node node) {
        if (node instanceof FeatureType) {
            return null;
            // getChildNodes should NOT return an empty FeatureMap for feature leaves.
            // A FeatureMap must have an owner, if a dummy FeatureMap is returned for null safety, the user might
            // attempt to add new entries to the dummy FeatureMap, assuming that the existence of a FeatureMap for children
            // implies that the node isn't a leaf. These would cause mappings to be lost, as the returned FeatureMap isn't
            // associated with any of the nodes of the feature model.
            // Please use null checks to recognize leaves.
        } else if (node instanceof BinaryNodeType) {
            return ((BinaryNodeType) node).getNodeListGroup();        
        } else if (node instanceof AndType) {
            return ((AndType) node).getNodeListGroup();
        } else {
            throw new RuntimeException("Unknown node type. This should't happen.");
        }
    }
}
