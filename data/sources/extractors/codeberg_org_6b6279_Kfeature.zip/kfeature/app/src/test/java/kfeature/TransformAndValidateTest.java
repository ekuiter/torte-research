package kfeature;

import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;

import org.junit.Test;

public class TransformAndValidateTest {

    @Test
    public void simpleBooleanDependencyTest() throws URISyntaxException, InterruptedException {
        /*
         * Tests transformation of boolean configuration symbols with multiple
         * dependencies.
         * 
         * Takes about 6 seconds to complete. 32 possible configurations, 16 unique
         * configurations once abstract features are ommited, 6 solutions. 100% hit
         * rate on both valid and invalid configurations.
         */
        URL kconfigFile = getClass().getResource("/Kconfig1");
        String[] args = { "-i", kconfigFile.getFile().toString() };
        App.main(args);
        URL featureModel = getClass().getResource("/Kconfig1_feature-model.xml");
        assert (KFeatureValidator.validateTransformation(Path.of(kconfigFile.toURI()), Path.of(featureModel.toURI())));
    }

    @Test
    public void booleanChoiceBlockTest() throws URISyntaxException, InterruptedException {
        /*
         * Tests transformation of boolean choice blocks (both optional and mandatory)
         * with multiple dependencies that are defined inside menu blocks.
         * 
         * Takes about 20 seconds to complete. 1024 possible configurations, 64 unique
         * configurations once abstract features are ommited, 11 solutions. 100% hit
         * rate on both valid and invalid configurations.
         */
        URL kconfigFile = getClass().getResource("/Kconfig2");
        String[] args = { "-i", kconfigFile.getFile().toString() };
        App.main(args);
        URL featureModel = getClass().getResource("/Kconfig2_feature-model.xml");
        assert (KFeatureValidator.validateTransformation(Path.of(kconfigFile.toURI()), Path.of(featureModel.toURI())));
    }

    @Test
    public void menuBlockTest() throws URISyntaxException, InterruptedException {
        /*
         * Tests transformation of menu blocks and `menuconfig` configuration symbols.
         * 
         * Takes about 42 seconds to complete. 512 possible configurations, 128 unique
         * configurations once abstract features are ommited, 64 solutions. 100% hit
         * rate on both valid and invalid configurations.
         */
        URL kconfigFile = getClass().getResource("/Kconfig3");
        String[] args = { "-i", kconfigFile.getFile().toString() };
        App.main(args);
        URL featureModel = getClass().getResource("/Kconfig3_feature-model.xml");
        assert (KFeatureValidator.validateTransformation(Path.of(kconfigFile.toURI()), Path.of(featureModel.toURI())));
    }

    @Test
    public void selectDependencyChainTest() throws URISyntaxException, InterruptedException {
        /**
         * Tests transformation of `select` dependencies and mandatory/optional boolean choice blocks.
         * Takes about 25 seconds to complete.
         */
        URL kconfigFile = getClass().getResource("/Kconfig4");
        String[] args = { "-i", kconfigFile.getFile().toString() };
        App.main(args);
        URL featureModel = getClass().getResource("/Kconfig4_feature-model.xml");
        assert (KFeatureValidator.validateTransformation(Path.of(kconfigFile.toURI()), Path.of(featureModel.toURI())));
    }

    @Test
    public void menuconfigBooleanDependencyChainTest() throws URISyntaxException, InterruptedException {
        /*
         * Tests transformation of multiple dependencies and dependencies on `menuconfig` symbols in dependency chains.
         * Takes about 45 seconds to complete.
         */
        URL kconfigFile = getClass().getResource("/Kconfig5");
        String[] args = { "-i", kconfigFile.getFile().toString() };
        App.main(args);
        URL featureModel = getClass().getResource("/Kconfig5_feature-model.xml");
        assert (KFeatureValidator.validateTransformation(Path.of(kconfigFile.toURI()), Path.of(featureModel.toURI())));
    }
}