# Kfeature

Kfeature transforms Kconfig files into feature models. The created feature models can be then viewed and processed further using FeatureIDE.
Kfeature was inspired by Sincero and Preikschat's paper on Kconfig as a feature modelling tool [1].

Currently, Kfeature can transform following Kconfig constructs:

- Boolean configuration symbols
- Tristate configuration symbols
- Multiple dependencies (also mixed-type, i.e. among and between boolean or resp. tristate confsyms)
- Menu blocks
- Menuconfig symbols (only boolean-type)
- Boolean choice blocks
- Tristate choice blocks
- Reverse dependencies (partially)

Kfeature cannot process Kconfig files with...

- composite dependency expressions
- string/hex/integer-valued configuration symbols
- `source` (due to parser constraints)
- `modules` (although the configuration symbol itself gets transformed correctly)

Kfeature was developed in scope of [a bachelor's thesis](https://publikationen.bibliothek.kit.edu/1000162110) at the Karlsruhe Institute for Technology.
The transformations implemented in Kfeature are further discussed and presented in the thesis.

[A shorter adaptation](https://dl.acm.org/doi/10.1145/3634713.3634731) of the thesis was submitted to [VaMoS '24](https://vamos2024.inf.unibe.ch/). This repository hence also functions as the artifact submission to the conference.

## Code overview

Kfeature implements a three-step pipeline to transform a Kconfig file into a FeatureIDE feature model:

  1. First, a Kconfig file is parsed into a syntax tree using
     ANTLR3. We use the grammar file provided in
     [kconfig-g](https://code.google.com/archive/p/kconfig-g) by
     Steven She (alias mintcoffee).

  2. The syntax tree is then transformed into a graph. This is done by
     the `TreeProcessor` class. `TreeProcessor` is a stateful but
     disposable class; a `TreeProcessor` instance can be used to process
     only one syntax tree. The entry point of this class is
     `processAST`. `processAST` differs between the different Kconfig
     constructs that may occur as the children of the file root (menu
     blocks, choice blocks, configuration symbols) and calls the
     respective sub-routines to handle the individual structures. We
     use a record type `KConfigGraph` to represent this intermediate
     graph form: All configuration symbols, menu blocks and choice
     blocks are considered nodes of the graph, wherein dependencies
     are the edges. There are so-called "enclosing nodes", this is
     used to model the relationship between the menu block node and
     the individual configuration symbols that occur in that menu
     block: This is not a dependency in the usual sense, hence such a
     relationship is not modelled through edges. We use a dedicated
     `KConfigNode` class to store the type, name and other intristric
     features (optionality, enclosing node) of the Kconfig structure
     that corresponds to the resp. node in `KConfigGraph`.

  3. The graph is then transformed into a feature model. This is done
     by the `FeatureIDEXSDGraphProcessor` class. This class is static
     and has no state; the `processGraph` method creates a complete
     feature model using a `KConfigGraph` instance and returns the
     created feature model as a `FeatureModelType` ECore object.

     `FeatureIDEXSDGraphProcessor` contains two large methods:
     `processNode` and `processRule`. These methods implement the
     atomic transformation rules listed above. There are some utility
     methods in `FeatureIDEXSDGraphProcessor`, such as
     `buildSimpleImplication`.

     In its current form, `FeatureIDEXSDGraphProcessor` is a god
     class: `processRule` differs between type pairs with a nested
     `switch` block. A possible re-implementation of step 3 with a
     pseudo-visitor design pattern (one class for every possible
     2-node type combination) is in the making.

  4. The created feature model can then be serialized using
     `FeatureIDEXSDSerializer`, which ultimately creates a XML file
     that can be loaded in FeatureIDE.

As already mentioned, the feature model returned by `processGraph` in
step 3 is represented in term of ECore objects. The metamodel used to
generate the respective classes of these ECore objects was taken from
[2]. The schema for the metamodel was created by XMLSpy through sample
analysis.

## Testing and verification

Transformation of Kconfig files without any tristate symbols can be
verified using [kmax](https://github.com/paulgazz/kmax). Five sample
Kconfig files that may be verified automatically using kmax are
included in this repository, see `TransformAndValidateTest`. There is
a command-line argument `-c` (*c*heck) for automatically calling
`KFeatureValidator` on the created feature model. This class realises
the automatic verification process with kmax.

## Using Kfeature yourself

If you are interested in, for example, replicating the evaluation results with the provided Kconfig files, you can locally build Kfeature and run it yourself:

1. Clone this repository.

2. Kfeature uses FeatureIDE 3.9.3 (more specifically
   `de.ovgu.featureide.lib.fm`), the library is bound over a static
   JAR file. You need to download the corresponding JAR file from [the 3.9.2 release](https://github.com/FeatureIDE/FeatureIDE/releases/tag/v3.9.2)
   and copy it over to `app/libs`, alongside with the static
   dependencies of FeatureIDE itself (but not ANTLR 3.4, as we use ANTLR 3.5.2 as a direct dependency), which you can find over at the
   [GitHub repository of the respective package](https://github.com/FeatureIDE/FeatureIDE/tree/develop/plugins/de.ovgu.featureide.fm.core/lib).

3. Install kmax. This is best done with `pipx`, e.g. `pipx install kmax`.

4. Now you can run Kfeature over Gradle, e.g. `./gradlew run`. You can pass command-line arguments to Kfeature with the `--args` flag.
   Simply running `./gradlew build` will execute the unit tests, which correspond to the automatic evaluation done in the thesis.
   You can find the artifacts used for manual evaluation over [at Zenodo](https://zenodo.org/records/10060586).

   There are three simple command-line flags to use:
   - `-i`: Path to the input Kconfig file
   - `-o`: Path to the output FeatureIDE XML file (optional)
   - `-c`: If present, try to validate generated feature model (as mentioned above, only for Kconfig files with constructs that both support by kmax and Kfeature)
   You can inquire more about the command-line interface in the comments of the `kfeature.App` class.

## Bibliography

[1] J. Sincero and W. Schröder-Preikschat, ‘The Linux Kernel
Configurator as a Feature Modeling Tool’, in Software Product Lines,
12th International Conference, SPLC 2008, Limerick, Ireland, September
8-12, 2008, Proceedings. Second Volume (Workshops), S. Thiel and
K. Pohl, Eds., Lero Int. Science Centre, University of Limerick,
Ireland, 2008, pp. 257–260.

[2] A. Ateş, ‘Konsistenzerhaltung von Feature-Modellen durch externe Sichten’, 2022, doi: 10.5445/IR/1000143212.
