///////////////////////////////////////////////////////////////////////////
//                   __                _      _   ________               //
//                  / /   ____  ____ _(_)____/ | / / ____/               //
//                 / /   / __ \/ __ `/ / ___/  |/ / / __                 //
//                / /___/ /_/ / /_/ / / /__/ /|  / /_/ /                 //
//               /_____/\____/\__, /_/\___/_/ |_/\____/                  //
//                           /____/                                      //
//                                                                       //
//               The Next Generation Logic Library                       //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
//                                                                       //
//  Copyright 2015-20xx Christoph Zengler                                //
//                                                                       //
//  Licensed under the Apache License, Version 2.0 (the "License");      //
//  you may not use this file except in compliance with the License.     //
//  You may obtain a copy of the License at                              //
//                                                                       //
//  http://www.apache.org/licenses/LICENSE-2.0                           //
//                                                                       //
//  Unless required by applicable law or agreed to in writing, software  //
//  distributed under the License is distributed on an "AS IS" BASIS,    //
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or      //
//  implied.  See the License for the specific language governing        //
//  permissions and limitations under the License.                       //
//                                                                       //
///////////////////////////////////////////////////////////////////////////

package org.logicng.backbones;

/**
 * An enumeration which type of backbone should be computed:
 * <ul>
 * <li> {@code ONLY_POSITIVE}: only variables which occur positive in every model
 * <li> {@code ONLY_NEGATIVE}: only variables which occur negative in every model
 * <li> {@code POSITIVE_AND_NEGATIVE}: variables which occur positive in every model,
 * variables which occur negative in every model and optional variables (neither in the
 * positive nor negative backbone)
 * </ul>
 * @version 1.5.0
 * @since 1.5.0
 */
public enum BackboneType {
    /**
     * Only variables in the positive backbone
     */
    ONLY_POSITIVE,

    /**
     * Only variables in the negative backbone
     */
    ONLY_NEGATIVE,

    /**
     * Variables in the positive backbone, in the negative backbone and optional
     */
    POSITIVE_AND_NEGATIVE
}
